setwd("C:\\Users\\mhmhi\\OneDrive\\Desktop\\PS_Lab_6")

#01(i)
n <- 50
p <- 0.85
cat("X ~ Binomial(",n,",",p,")")

#01(ii)
p1 <- pbinom(46,n,p)
p1

#02(i)
# X = Number of calls received in one hour

#02(ii)
lamda <- 12
cat("X ~ Poisson (", lamda,")")

#02(iii)
dpois(15,lambda = lamda)

