setwd("C:\\Users\\mhmhi\\OneDrive\\Desktop\\PS_Lab_9")

#random sample of size 25 for the baking time
sample <- rnorm(25, mean =45, sd =2)

# Test whether the average baking time is less than 46 minutes at a 5% level of significance.
t.test (sample, mu=46, alternative = "less")
